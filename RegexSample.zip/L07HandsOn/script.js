function validateName()
{
 //USER ENTERS FIRST AND LAST NAMES
    var fName=document.getElementById("firstName").value;
    var lName=document.getElementById("lastName").value;

//THE NEXT TWO DECLARATIONS ARE THE REGULAR EXPRESSION PATTERN MATCHES.
//
//THE FIRST ONE CHECKS FOR PROPER CASE AND FORMAT OF BOTH FIRST AND LAST NAMES
    var theNamePatternRegex=/^[A-Z][a-z]+$/g;
//THE SECOND ONE CHECKS FOR A NON-WORD CHARACTER
    var hasNonWordRegex=/(\W|\d)+/;

//INITIALIZE THE ERROR MESSAGE VARIABLE
    var errorMessage = "";
//CHECK TO MAKE SURE USER DOES NOT ENTER BLANK IN EITHER FIRST NAME OR LAST NAME FIELD
    if(fName == "" || lName == "")
    {
        alert("CANNOT ACCEPT BLANK INPUT!");
        return;
    }
//HERE WE VERIFY WHAT THE USER ENTERED
    alert("your entered " + fName + " " + lName);

    if (fName.match(theNamePatternRegex) && lName.match(theNamePatternRegex))
    {
//IF THE PATTERN CHECKS OUT THAT THE INITIAL LETTER IS CAPITAL AND REST OF STRING IS LOWER CASE
//IT WRITES THE MESSAGE ON THE PAGE THAT THE NAME IS ACCEPTABLE
        alert(fName + " " + lName  + " is acceptable");
       let feedback=document.createElement('h2');
       let feedbackMessage=document.createTextNode(fName + " " + lName + " is acceptable");
       feedback.appendChild(feedbackMessage);
        document.body.appendChild(feedback);
    }
//CHECKING FOR PROBLEMMATIC INPUTS:
    else
    {//ONLY ONE LETTER
        if (fName.length === 1) 
        {
           errorMessage += "the first name " + fName + " is only one letter; ";
         }
     if (lName.length === 1 )
        {
            errorMessage += "the last name " + lName + " is only one letter; ";
        }
//INITIAL LETTER NOT CAPITALIZED
     if (fName.substr(0,1) !== fName.substr(0,1).toUpperCase())
        {
            errorMessage += "the first name " + fName + " does not start with capital letter; ";
        }
    if (lName.substr(0,1) !== lName.substr(0,1).toUpperCase())
        {
            errorMessage += "the last name " + lName + " does not start with capital letter; ";
        }
//MISPLACED CAPITAL LETTERS
  if (fName.substr(1) !== fName.substr(1).toLowerCase())
        {
            errorMessage += "the first name " + fName + " has one or more capital letters in wrong position; "
        }
 if (lName.substr(1) !== lName.substr(1).toLowerCase()) 
        {
            errorMessage += "the last name " + lName + " has one or more capital letters in wrong position; "
        } 
//AND NOW CHECKING FOR A NON-LETTER CHARACTER     
        if (fName.match(hasNonWordRegex))
        {
            errorMessage += "the first name " + fName + " has a non-letter character; ";
        }   
        if (lName.match(hasNonWordRegex))
        {
            errorMessage += "the last name " + lName + " has a non-letter character; ";
        }      
    }
//FINALLY IF THERE ARE ERRORS, DISPLAY WHAT THEY ALL ARE
   if (errorMessage !== "")
   {
    let feedback=document.createElement('h2');
    let feedbackMessage=document.createTextNode(errorMessage);
    feedback.appendChild(feedbackMessage);
     document.body.appendChild(feedback);
   }
  
}


