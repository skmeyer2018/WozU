import React from 'react';
import ReactDOM from 'react-dom';

import './App.css';


const App = props => {
  return (
    <div>
    <DateTimeCheck />
      </div>
  );
};   


class DateTimeCheck extends React.Component{
  constructor (props) {
    super (props);
    this.state = {
      currentDateTime: ''
    };
}
 componentDidMount ()
 {
   this.getDate();
   if (!this.state.intervalIsSet) {
    let interval = setInterval(this.getDate, 1000);
    this.setState({intervalIsSet: interval});
   }
 }
 getDate = () =>
 {
   let newDate = new Date();
   let theDate=newDate.toDateString()
   let theHour=newDate.getHours();
    let theMinute=newDate.getMinutes();
    let theSecond=newDate.getSeconds();
    if (theMinute < 10) theMinute="0"+theMinute;
    if (theSecond < 10) theSecond="0"+theSecond;
    let theTime=theHour + ":" + theMinute + ":" + theSecond;
   this.setState({currentDateTime: theDate + " " + theTime});
 }

render () {
 return (
  <div>
      <input type="hidden" onChange={event => this.setState({currentDateTime: event.target.value})} value={this.state.currentDateTime}/>
      <h2 onChange={event => this.setState({currentDateTime: event.target.value})} >{this.state.currentDateTime} </h2>
  </div>
  );
}

}



/*
function getTheDate() 
{

  let newDate=new Date();
  let theDate=newDate;
 // let theHour=newDate.getHours();
 // let theMinute=newDate.getMinutes();
//  let theSecond=newDate.getSeconds();
  //theMinute=CheckTime(theMinute);
  //theSecond=CheckTime(theSecond);
 // let theTime=theHour + ":" + theMinute + ":" + theSecond;
  //let t = setTimeout(function(){DateTimeCheck()}, 500);
    return theDate;
}
*/


ReactDOM.render(<App />, document.getElementById('root'));
export default App;
