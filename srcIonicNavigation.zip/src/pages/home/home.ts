import { Component } from '@angular/core';

import {P1Page} from '../p1/p1';
import {P2Page} from '../p2/p2';
import {AboutPage} from '../about/about';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})



export class HomePage {
  aboutPage = AboutPage;
  P1=P1Page;
  P2=P2Page;
  homePage=HomePage;
  constructor() {
 
  }

}

