import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { P1Page } from './p1';

@NgModule({
  declarations: [
    P1Page,
  ],
  imports: [
    IonicPageModule.forChild(P1Page),
  ],
})
export class P1PageModule {}
