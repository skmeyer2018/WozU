import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { P2Page } from './p2';

@NgModule({
  declarations: [
    P2Page,
  ],
  imports: [
    IonicPageModule.forChild(P2Page),
  ],
})
export class P2PageModule {}
